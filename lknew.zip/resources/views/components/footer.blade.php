<div class="footer mt-5 py-3 bg-light">
    <div class="container text-center">
        &copy; {{ date('Y') }} AppName. All Rights Reserved.
    </div>
</div>
