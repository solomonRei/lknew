<?php $__env->startSection('title', 'User Profile'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row">
            <div class="col-12">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#"><?php echo e(__('messages.breadcrumbs.home')); ?></a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('messages.profile')); ?></li>
                    </ol>
                </nav>
                <div class="card">
                    <div class="card-header">
                        <h5><?php echo e(__('messages.my_data')); ?></h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('profile.update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="name"><?php echo e(__('messages.name_label')); ?></label>
                                <input type="text" class="form-control" name="name" id="name" placeholder="<?php echo e(__('messages.name')); ?>" value="<?php echo e($profile->name ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label for="phone"><?php echo e(__('messages.phone_label')); ?></label>
                                <input type="text" class="form-control" name="phone" id="phone" placeholder="<?php echo e(__('messages.phone')); ?>" value="<?php echo e($profile->phone ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label for="telegram"><?php echo e(__('messages.telegram_chat_id_label')); ?></label>
                                <input type="text" class="form-control" name="telegram_chat_id" id="telegram" placeholder="<?php echo e(__('messages.telegram_chat_id')); ?>" value="<?php echo e($profile->telegram_chat_id ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label for="city"><?php echo e(__('messages.city_label')); ?></label>
                                <input type="text" class="form-control" name="city" id="city" placeholder="<?php echo e(__('messages.city')); ?>" value="<?php echo e($profile->city ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label for="address"><?php echo e(__('messages.address_label')); ?></label>
                                <input type="text" class="form-control" name="address" id="address" placeholder="<?php echo e(__('messages.address')); ?>" value="<?php echo e($profile->address ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label for="passport"><?php echo e(__('messages.passport_data_label')); ?></label>
                                <input type="text" class="form-control" name="passport_data" id="passport" placeholder="<?php echo e(__('messages.passport_data')); ?>" value="<?php echo e($profile->passport_data ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label for="email"><?php echo e(__('messages.email')); ?></label>
                                <input type="email" class="form-control" id="email" placeholder=<?php echo e(__('messages.email')); ?>" value="<?php echo e(Auth::user()->email); ?>" disabled>
                            </div>
                            <div class="form-group password-field" style="display: none;">
                                <label for="new_password"><?php echo e(__('messages.new_password_label')); ?></label>
                                <input type="password" class="form-control" name="new_password" id="new_password" placeholder="<?php echo e(__('messages.new_password')); ?>">
                            </div>
                            <br>
                            <div class="form-group">
                                <button type="button" class="btn btn-info" id="changePasswordButton"><?php echo e(__('messages.change_password')); ?></button>
                            </div>
                            <br>
                            <div class="d-flex justify-content-between">
                                <button type="button" class="btn btn-secondary"><?php echo e(__('messages.cancel')); ?></button>
                                <button type="submit" class="btn btn-primary"><?php echo e(__('messages.save')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if(session('success')): ?>
        <script>
            window.onload = () => {
                showSuccessAlert('<?php echo e(session('success')); ?>');
            };
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        document.getElementById('changePasswordButton').addEventListener('click', function() {
            let passwordFields = document.querySelectorAll('.password-field');
            passwordFields.forEach(function(field) {
                field.style.display = field.style.display === 'none' ? 'block' : 'none';
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\lknew\resources\views/front/index.blade.php ENDPATH**/ ?>