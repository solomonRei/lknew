<div class="footer mt-5 py-3 bg-light">
    <div class="container text-center">
        &copy; <?php echo e(date('Y')); ?> AppName. All Rights Reserved.
    </div>
</div>
<?php /**PATH W:\domains\lknew\resources\views/components/footer.blade.php ENDPATH**/ ?>