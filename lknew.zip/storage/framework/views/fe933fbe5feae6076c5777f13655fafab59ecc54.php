<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <input type="checkbox" id="check">
        <div class="login form">
            <header><?php echo e(__('messages.auth.enter.login')); ?></header>
            <?php if($errors->any()): ?>
                <script>
                    window.onload = () => {
                        showErrorAlert(`<?php echo implode('', $errors->all('<div>:message</div>')); ?>`);
                    };
                </script>
            <?php endif; ?>
            <form action="<?php echo e(route('auth.login')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="email" name="email" placeholder="<?php echo e(__('messages.auth.enter.email')); ?>" required>
                <input type="password" name="password" placeholder="<?php echo e(__('messages.auth.enter.password')); ?>" required>
                <a href="#"><?php echo e(__('messages.auth.enter.forgot')); ?></a>
                <input type="submit" class="button" value="<?php echo e(__('messages.auth.enter.login')); ?>">
            </form>
            <div class="signup">
        <span class="signup"><?php echo e(__('messages.auth.enter.dont_have_an_account')); ?>

         <label for="check"><?php echo e(__('messages.auth.enter.signup')); ?></label>
        </span>
            </div>
        </div>
        <div class="registration form">
            <header><?php echo e(__('messages.auth.enter.signup')); ?></header>
            <?php if($errors->any()): ?>
                <script>
                    window.onload = () => {
                        showErrorAlert(`<?php echo implode('', $errors->all('<div>:message</div>')); ?>`);
                    };
                </script>
            <?php endif; ?>
            <form action="<?php echo e(route('auth.register')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="email" name="email" placeholder="<?php echo e(__('messages.auth.enter.email')); ?>" required>
                <input type="password" name="password" placeholder="<?php echo e(__('messages.auth.enter.password')); ?>" required>
                <input type="password" name="password_confirmation" placeholder="<?php echo e(__('messages.auth.enter.password.confirm')); ?>" required>
                <input type="submit" class="button" value="<?php echo e(__('messages.auth.enter.signup')); ?>">
            </form>
            <div class="signup">
        <span class="signup"><?php echo e(__('messages.auth.enter.already_have_an_account')); ?>

         <label for="check"><?php echo e(__('messages.auth.enter.login')); ?></label>
        </span>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\lknew\resources\views/front/login.blade.php ENDPATH**/ ?>